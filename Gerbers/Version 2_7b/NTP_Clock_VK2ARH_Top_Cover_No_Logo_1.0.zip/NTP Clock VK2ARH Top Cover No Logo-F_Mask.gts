G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.6*
G04 #@! TF.CreationDate,2026-07-06T15:49:22+10:00*
G04 #@! TF.ProjectId,NTP Clock VK2ARH Top Cover No Logo,4e545020-436c-46f6-936b-20564b324152,1.0*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.6) date 2026-07-06 15:49:22*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
